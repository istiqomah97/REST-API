from django.contrib import admin
from itemsapp.models import ItemsModel
admin.site.register(ItemsModel)


# Register your models here.
