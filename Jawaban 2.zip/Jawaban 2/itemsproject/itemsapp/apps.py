from django.apps import AppConfig


class ItemsappConfig(AppConfig):
    name = 'itemsapp'
