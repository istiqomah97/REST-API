from django.contrib import admin
from items_app.models import ItemsModel

# Register your models here.
admin.site.register(ItemsModel)